drop database PizzaDelivery;
create database PizzaDelivery;
use PizzaDelivery;

create table user_mst(username varchar(30) Primary Key, password varchar(30), name varchar(30), email varchar(40), address1 varchar(100),locality varchar(40),city varchar(50), phone varchar(20));




create table pizza_mst(name varchar(30), price int(4),image varchar(100));
insert into pizza_mst values("Veggie Surprise",200,"/images/1.jpeg");
insert into pizza_mst values("Chicken Surprise",250,"/images/4.jpg");
insert into pizza_mst values("Veggie Supreme",280,"/images/2.png");
insert into pizza_mst values("Chicken Supreme",330,"/images/1.jpeg");


create table order_trn(id int(3)AUTO_INCREMENT PRIMARY KEY, name varchar(30),address varchar(100),date varchar(60),amount varchar(10));
