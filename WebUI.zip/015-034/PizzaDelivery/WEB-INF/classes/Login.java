import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.*;
public class Login extends HttpServlet 
{
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
		
		HttpSession session = req.getSession();
		ArrayList<ArrayList<String>> order = new ArrayList<ArrayList<String>>();
		
		
		Connection con;
		PreparedStatement ps;
		ResultSet rs;
		String username=req.getParameter("username");
		String password=req.getParameter("password");
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
			
		session.setAttribute("cart",order);

		out.println("<html><head><title>User Info</title></head><body>");
		try
		{
			String connectionURL="jdbc:mysql://localhost:3306/PizzaDelivery";
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			con=DriverManager.getConnection(connectionURL,"root","manshani");
			String sql="select * from user_mst where username='"+username+"' and password='"+password+"';";
			ps=con.prepareStatement(sql);
			rs=ps.executeQuery();
			username="Not Found";
			if(rs.next())
			{
				username=rs.getString(1);
			}
			if(username.equals("Not Found"))
			{
				res.sendRedirect("notFound.jsp");
			}
			String address=rs.getString(5)+" "+rs.getString(6)+" "+rs.getString(7);
			session.setAttribute("address",address);	//these session attributes are set as they will be required
			session.setAttribute("username",username);	// while processing payment.
			res.sendRedirect("pizzaMenu.jsp");
		}
		catch(Exception e){
			out.println("EXCEPTION: " + e);
		}
		out.close();
	}
}

	
