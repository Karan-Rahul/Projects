import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.*;
public class Register extends HttpServlet 
{
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException
	{
		Connection con;
		PreparedStatement ps;
		PrintWriter out=response.getWriter();
		out.println("<html><head>");
		try
		{
			String connectionURL="jdbc:mysql://localhost:3306/PizzaDelivery";
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			con=DriverManager.getConnection(connectionURL,"root","manshani");
			String sql="insert into user_mst values (?,?,?,?,?,?,?,?)";		

			ps=con.prepareStatement(sql);

			ps.setString(1,request.getParameter("username"));
			ps.setString(2,request.getParameter("password1"));
			ps.setString(3,request.getParameter("name"));
			ps.setString(4,request.getParameter("email"));
			ps.setString(5,request.getParameter("address"));
			ps.setString(6,request.getParameter("localityList"));
			ps.setString(7,request.getParameter("cityList"));
			ps.setString(8,request.getParameter("phone"));

			int result=ps.executeUpdate();
			out.println("<script language=javascript>alert(\"You have been registered.\");</script></head><body /></html>");
			response.sendRedirect("login.html");
		}
		catch(Exception e)
		{
			response.sendRedirect("login.html");
			out.println("<h4>Error------------Please Check Error Log ....</h4>");
			System.out.println("Error !!! ");
			e.printStackTrace();
		}
	}
}
